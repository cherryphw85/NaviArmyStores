# 🪖 Navi Army Store

India's trusted military uniform & tactical gear online store.

## Live Deploy on Netlify (Free - Recommended)

1. Go to https://netlify.com → Sign up with GitHub  
2. Click **"Add new site"** → **"Import an existing project"**  
3. Choose **GitHub** → select **navi-army-store** repo  
4. Build settings (auto-detected):  
   - Build command: `npm run build`  
   - Publish directory: `build`  
5. Click **"Deploy site"** ✅

Your site will be live at: **https://navi-army-store.netlify.app**

---

## Live Deploy on Vercel (Also Free)

1. Go to https://vercel.com → Sign up with GitHub  
2. Click **"New Project"** → Import **navi-army-store**  
3. Click **"Deploy"** ✅

---

## Local Development

```bash
npm install
npm run dev
```

Open http://localhost:5173

## Build for Production

```bash
npm run build
```
